import pymysql,itertools

class cn_sql:
    def __init__(self):
        self.dbname = 'test'
        self.user = 'xzw'
        self.password = 'xzw123'
        self.host = '192.168.232.128'
        self.port = 3306
        self.connection = pymysql.connect(db=self.dbname,user=self.user,password=self.password,host=self.host,port=self.port,charset='utf8')

    def set_sql(self,sql):
        cursor = self.connection.cursor()
        cursor.execute(sql)
        # result = cursor.fetchone()
        result = cursor.fetchall()
        sqlmsg = (list(itertools.chain.from_iterable(set(result))))
        return sqlmsg
        self.connection.close()

if __name__ == "__main__":
    cnsql = cn_sql()
    sqls = cnsql.set_sql("select 厂商 from tb_tmp1;")
    xinxi = (','.join(sqls))
    print("船只厂商信息如下: %s" % (xinxi))